#include <iomanip> 
#include <cstring> 
#include <stdlib.h>
#include <conio.h>
#include <stdio.h> 
#include <fstream>                  
#include <iostream>

using namespace std;

struct Hasta
{
    char ad[80];
    char soyad[80];
    char tc_no[11];
    char cinsiyet;
    char randevu_tarihi[12];
};
void HastaEkle();
void HastaListeleme();
void HastaArama();
void HastaSil();
void HastaDuzenle();

int main() {
    char anamenu;
    do {
        system("cls");
        cout << "|-------Poliklinik Otomasyonu-------|" << endl;
        cout << "|      Secim Yapiniz               |" << endl;
        cout << "|   1- Hasta Ekleme                |" << endl;
        cout << "|   2- Hasta Listeleme             |" << endl;
        cout << "|   3- Hasta Arama                 |" << endl;
        cout << "|   4- Hasta Sil                   |" << endl;
        cout << "|   5- Hasta Duzenle               |" << endl;
        cout << "|----------------------------------|" << endl;

        char secim;
        cin >> secim;

        switch (secim) {
            case '1':
                HastaEkle();
                break;
            case '2':
                HastaListeleme();
                break;
            case '3':
                HastaArama();
                break;
            case '4':
                HastaSil();
                break;
            case '5':
                HastaDuzenle();
                break;
        }

        cout << "Ana menuye donmek icin: a basin, cikmak icin: c" << endl;
        anamenu = getche();

    } while (anamenu == 'a');

    return 0;
}

Hasta hasta;

void HastaEkle() {
    ofstream yaz("hasta.dat", ios::binary | ios::app);
    char secim;
    int adet = 0;

    do {
        cout << "\nHasta Adi Giriniz: ";
        cin >> hasta.ad;
        cout << "Hasta Soyadi Giriniz: ";
        cin >> hasta.soyad;
        cout << "Hasta TC No Giriniz: ";
        cin >> hasta.tc_no;
        cout << "Hasta Cinsiyet Giriniz (E/K): ";
        hasta.cinsiyet = getche();
        cout << "\nRandevu Tarihi Giriniz (GG/AA/YYYY): ";
        cin >> hasta.randevu_tarihi;

        yaz.write((char*)&hasta, sizeof(hasta));
        adet++;

        cout << "\nBaska Kayit Eklemek Istiyor musunuz? (E/H): ";
        secim = getche();
        cout << endl;
    } while (secim == 'e' || secim == 'E');

    cout << adet << " adet hasta eklendi.\n";
    yaz.close();
}

void HastaListeleme() {
    ifstream oku("hasta.dat", ios::binary);
    oku.seekg(0, ios::end);
    int kayitsayisi = oku.tellg() / sizeof(hasta);

    cout << "\nToplam Hasta Kayit Sayisi: " << kayitsayisi << endl;

    if (kayitsayisi > 0) {
        oku.seekg(0, ios::beg);
        for (int i = 0; i < kayitsayisi; i++) {
            oku.read((char*)&hasta, sizeof(hasta));

            cout << "\n" << i + 1 << ". Hastanin Bilgileri" << endl;
            cout << "Adi: " << hasta.ad << endl;
            cout << "Soyadi: " << hasta.soyad << endl;
            cout << "TC No: " << hasta.tc_no << endl;
            cout << "Cinsiyet: " << (hasta.cinsiyet == 'e' || hasta.cinsiyet == 'E' ? "Erkek" : "Kadin") << endl;
            cout << "Randevu Tarihi: " << hasta.randevu_tarihi << endl;
        }
    } else {
        cout << "Kayit bulunamadi.\n";
    }

    oku.close();
}

void HastaArama() {
    ifstream oku("hasta.dat", ios::binary);
    oku.seekg(0, ios::end);
    int kayitsayisi = oku.tellg() / sizeof(hasta);

    cout << "Aranacak Hasta TC No Giriniz: ";
    char tc_no[11];
    cin >> tc_no;

    bool bulundu = false;
    if (kayitsayisi > 0) {
        oku.seekg(0, ios::beg);
        for (int i = 0; i < kayitsayisi; i++) {
            oku.read((char*)&hasta, sizeof(hasta));

            if (strcmp(hasta.tc_no, tc_no) == 0) {
                bulundu = true;
                cout << "\nBulunan Hastanin Bilgileri" << endl;
                cout << "Adi: " << hasta.ad << endl;
                cout << "Soyadi: " << hasta.soyad << endl;
                cout << "TC No: " << hasta.tc_no << endl;
                cout << "Cinsiyet: " << (hasta.cinsiyet == 'e' || hasta.cinsiyet == 'E' ? "Erkek" : "Kadin") << endl;
                cout << "Randevu Tarihi: " << hasta.randevu_tarihi << endl;
                break;
            }
        }
    }

    if (!bulundu) {
        cout << "\nHasta kaydi bulunamadi.\n";
    }

    oku.close();
}

void HastaSil() {
    char tc_no[11];
    cout << "Silinecek Hasta TC No Giriniz: ";
    cin >> tc_no;

    ifstream oku("hasta.dat", ios::binary);
    ofstream yaz("yedek.dat", ios::binary);

    oku.seekg(0, ios::end);
    int kayitsayisi = oku.tellg() / sizeof(hasta);
    bool bulundu = false;

    if (kayitsayisi > 0) {
        oku.seekg(0, ios::beg);
        for (int i = 0; i < kayitsayisi; i++) {
            oku.read((char*)&hasta, sizeof(hasta));

            if (strcmp(hasta.tc_no, tc_no) == 0) {
                bulundu = true;
                cout << "Kayit silindi.\n";
            } else {
                yaz.write((char*)&hasta, sizeof(hasta));
            }
        }
    }

    oku.close();
    yaz.close();

    remove("hasta.dat");
    rename("yedek.dat", "hasta.dat");

    if (!bulundu) {
        cout << "Kayit bulunamadi.\n";
    }
}

void HastaDuzenle() {
    char tc_no[11];
    cout << "Duzenlenecek Hasta TC No Giriniz: ";
    cin >> tc_no;

    ifstream oku("hasta.dat", ios::binary);
    ofstream yaz("yedek.dat", ios::binary);

    oku.seekg(0, ios::end);
    int kayitsayisi = oku.tellg() / sizeof(hasta);
    bool bulundu = false;

    if (kayitsayisi > 0) {
        oku.seekg(0, ios::beg);
        for (int i = 0; i < kayitsayisi; i++) {
            oku.read((char*)&hasta, sizeof(hasta));

            if (strcmp(hasta.tc_no, tc_no) == 0) {
                bulundu = true;
                cout << "Yeni Hasta Adi: ";
                cin >> hasta.ad;
                cout << "Yeni Hasta Soyadi: ";
                cin >> hasta.soyad;
                cout << "Yeni Hasta TC No: ";
                cin >> hasta.tc_no;
                cout << "Yeni Cinsiyet (E/K): ";
                hasta.cinsiyet = getche();
                cout << "\nYeni Randevu Tarihi (GG/AA/YYYY): ";
                cin >> hasta.randevu_tarihi;
            }

            yaz.write((char*)&hasta, sizeof(hasta));
        }
    }

    oku.close();
    yaz.close();

    remove("hasta.dat");
    rename("yedek.dat", "hasta.dat");

    if (bulundu) {
        cout << "\nKayit duzenlendi.\n";
    } else {
        cout << "\nKayit bulunamadi.\n";
    }
}
